Missing Files ?

If you do not run Windows 2000 or Windows XP, then you have to install the:
faxcom.dll in the Win32 system directory (please also register this DLL)

If you do not have the MS Office 2000 Pro. installed, you have to install the following files:
msacc9.olb, msppt9.olb, MSOUTL9.OLB, EXCEL9.OLB and the msword9.olb in the Microsoft Office/Office directory 
(if you have a MS Office with a lower version number, you could also just change the VB-referances)

Regardles what Windows version you run, you have to install:
dbGrid32.ocx, dbGrid32.oca and dbGrid32.dep in the Win32 system folder (please also register the dbGrid32.ocx)
(This is an old (VB5) Grid control).

The eztw32.dll is a library for scanning of pictures and the vbSendMail.dll is for sending of email without outlook installed, those dll have to be copied to the win32 system folder and also remember to register them.

Have a nice day
J�rgen Levesen